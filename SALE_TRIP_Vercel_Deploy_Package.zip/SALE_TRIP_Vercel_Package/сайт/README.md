# SALE TRIP — Vercel deployment package

Responsive static website for the SALE TRIP travel agency. Languages: Russian, Uzbek and English. Includes local image assets and editable SVG source artwork.

## Deploy to Vercel

1. Extract the ZIP archive.
2. In Vercel, choose **Add New → Project** and import the repository, or upload the project through the supported Git workflow.
3. Set **Root Directory** to `сайт` (the folder containing this `index.html` and `vercel.json`).
4. Framework preset: **Other**. Build Command: leave empty. Output Directory: `.`. Install Command: leave empty.
5. Deploy.

No build step or environment variables are required.

## Local preview

Open `index.html` directly, or run a local static server from this folder, for example:

```bash
python -m http.server 8080
```

Then visit `http://localhost:8080`.

## Included features

- Responsive desktop/tablet/mobile layout and mobile navigation.
- RU / UZ / EN language switcher (remembers choice in browser local storage).
- Service overview, “Why SALE TRIP”, destination ideas, booking process, FAQ and contact form.
- Contact form validates required fields and opens WhatsApp with a prepared enquiry. It does **not** send the message until the visitor confirms it in WhatsApp; no backend/email delivery is configured.
- SEO title/description, Open Graph metadata, SVG favicon, accessible form labels and reduced-motion support.
- Local SVG travel illustrations and optimized WebP logo; editable image source files are in `assets/images/` and `assets/source/`.

## Before going live

- Confirm the company name, tax ID, phone and email shown on the website.
- Add verified Telegram/Instagram URLs if you want them displayed.
- Review the privacy notice and publish a complete privacy policy that fits your business and local legal requirements.
- Test the WhatsApp link on desktop and mobile.
- The destination cards are inspirational examples, not offers with confirmed prices or availability.

## Image assets

- `assets/sale-trip-logo.webp` — optimized logo used by the page.
- `assets/source/sale-trip-logo-original.png` — original logo source extracted from the supplied HTML.
- `assets/source/sale-trip-logo-preview.jpg` — smaller preview copy.
- `assets/images/*.svg` — editable vector illustrations for the hero and destination cards.
- `assets/favicon.svg` — editable vector favicon.
