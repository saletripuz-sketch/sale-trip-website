SALE TRIP — Vercel package

Website root: сайт/

For Vercel, import the project and set Root Directory to "сайт". Framework preset: Other. No build command is required; Output Directory: .

See сайт/README.md for deployment steps, features, and launch checklist.
